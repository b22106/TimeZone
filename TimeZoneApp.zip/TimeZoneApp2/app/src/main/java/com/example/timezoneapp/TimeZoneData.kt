package com.example.timezoneapp

class TimeZoneData(var name: String, var time: String)